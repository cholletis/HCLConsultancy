﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace DALConsultancy
{
    public class DALCompanyDetails
    {

        public string[] GetUserRoles(string userName)
        {
            string[] roleListArray = null;
            //if (User.Identity.IsAuthenticated || Request.IsAuthenticated)
            //{                
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    List<string> roleList = new List<string>();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[Test_rolesForUser]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@Username", userName));
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        roleList.Add(reader["RoleName"].ToString());
                    }
                    roleListArray = roleList.ToArray();
                    return roleListArray;
                    // HttpContext.Current.User = new GenericPrincipal(new GenericIdentity(HttpContext.Current.User.Identity.Name), roleListArray);
                    //return roleListArray;
                }

            }
        }

        public DataTable GetCompanyDetails(int HRCategory)
        {

            //if (User.Identity.IsAuthenticated || Request.IsAuthenticated)
            //{                
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[test_sp_GetCompanyDetails]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@HRCategory", SqlDbType.Bit).Value = HRCategory;
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds.Tables[0];
                }

            }
        }
        public bool InsertCompanyDetails(string Name, string website, string FileName, string ContentType, byte[] Data, int screenID)
        {

            //if (User.Identity.IsAuthenticated || Request.IsAuthenticated)
            //{                
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[Test_sp_CreateCompanyDetails]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CompanyName", Name));
                    cmd.Parameters.Add(new SqlParameter("@website", website));
                    cmd.Parameters.Add(new SqlParameter("@FileName", FileName));
                    cmd.Parameters.Add(new SqlParameter("@ContentType", ContentType));
                    cmd.Parameters.Add(new SqlParameter("@Data", Data));
                    cmd.Parameters.Add(new SqlParameter("@PageID", screenID));
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return (rowsAffected >= 1);
                }

            }
        }
        public bool boolAttachFile(string FileName, string ContentType, byte[] data, int screenID, int SelectedValue)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[Test_sp_UploadFiles]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@FileName", FileName));
                    cmd.Parameters.Add(new SqlParameter("@ContentType", ContentType));
                    cmd.Parameters.Add(new SqlParameter("@Data", data));
                    cmd.Parameters.Add(new SqlParameter("@PageID", screenID));
                    cmd.Parameters.Add(new SqlParameter("@Page_SelectedValue", SelectedValue));
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return (rowsAffected >= 1);
                }

            }
        }
        public DataTable GetFileTypes()
        {

            //if (User.Identity.IsAuthenticated || Request.IsAuthenticated)
            //{                
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[test_sp_getFileTypes]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds.Tables[0];
                }
            }
        }
        public DataTable GetAttachedFileList(int PageID, int PageSelectedValue)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.Parameters.Add(new SqlParameter("@pageID", PageID));
                    cmd.Parameters.Add(new SqlParameter("@pageSelectedValue", PageSelectedValue));
                    cmd.CommandText = "[test_GetAttachedFiles]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds.Tables[0];
                }
            }
        }

        public DataTable DownLoadSelectedFile(int FileID)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.Parameters.Add(new SqlParameter("@FileID", FileID));
                    cmd.CommandText = "[test_downloadFile]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    return ds.Tables[0];
                }
            }
        }
        public bool UpdateCompanyDetails(string CompanyName, string WebSite, int CompanyID)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[Test_UpdateCompanyDetails]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CompanyName", CompanyName));
                    cmd.Parameters.Add(new SqlParameter("@WebSite", WebSite));
                    cmd.Parameters.Add(new SqlParameter("@CompanyID", CompanyID));
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return (rowsAffected >= 1);
                }

            }
        }
        public bool DeleteCompanyDetails(int CompanyID, int PageID)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[Test_DeleteCompanyDetails]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CompanyID", CompanyID));
                    cmd.Parameters.Add(new SqlParameter("@PageID", PageID));
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return (rowsAffected >= 1);
                }

            }
        }
        public bool ExitCompanyDetails(int CompanyID)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[Test_ExitCompanyDetails]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CompanyID", CompanyID));
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return (rowsAffected >= 1);
                }

            }
        }
        public bool DeleteSelectedFile(int FileID)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "[Test_DeleteSelecteddFile]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@FileID", FileID));
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return (rowsAffected >= 1);
                }

            }
        }

    }
}
