﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Security.Principal;

namespace Consultancy.Account
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //RegisterHyperLink.NavigateUrl = "Register.aspx?ReturnUrl=" + HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            //if (Request.IsAuthenticated && !string.IsNullOrEmpty(Request.QueryString["ReturnUrl"]))
            //{
            //    // This is an unauthorized, authenticated request... 
            //    Response.Redirect("~/Account/Unauthorized.aspx",false);
            //}
            
        }

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            //string[] roles;
            string username = txtUserName.Text.Trim();
            if (CheckUser(username, txtPassword.Text.Trim()) == true)
            {
                //These session values are just for demo purpose to show the user details on master page
                Session["User"] = username;
                
                
                //Session["Roles"] = roles;

                
                //Let us now set the authentication cookie so that we can use that later.
                FormsAuthentication.SetAuthCookie(username, false);
                FormsAuthentication.RedirectFromLoginPage(username, false);

                GetUserRoles(username);
                //Login successful lets put him to requested page
                //string returnUrl = Request.QueryString["ReturnUrl"] as string;

                //if (returnUrl != null)
                //{
                //    Response.Redirect(returnUrl);
                //}
                //else
                //{
                //    //no return URL specified so lets kick him to home page
                //    Response.Redirect("Default.aspx");
                //}
            }
            else
            {
                FailureText.Text = "Login Failed";                
            }
        }

        public static bool CheckUser(string username, string password)
        {
            DataTable result = null;
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
                {
                    using (SqlCommand cmd = con.CreateCommand())
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "select Password from Test_Users where UserName = @uname";
                        cmd.Parameters.Add(new SqlParameter("@uname", username));

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            result = new DataTable();
                            da.Fill(result);
                        }

                        if (password.Trim() == result.Rows[0]["password"].ToString().Trim())
                        {
                            //user id found and password is matched too so lets do soemthing now
                            return true;
                        }
                    }
                }
            }
            catch (Exception)
            {
                //Pokemon exception handling
            }

            //user id not found, lets treat him as a guest        
            return false;
        }

        private void GetUserRoles(string userName)
        {
            //string[] roleListArray=null;
            //if (User.Identity.IsAuthenticated || Request.IsAuthenticated)
            //{                
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnString_Consultancy"].ConnectionString))
                {
                    con.Open();
                    using (SqlCommand cmd = con.CreateCommand())
                    {
                        List<string> roleList = new List<string>();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "[Test_rolesForUser]";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@Username", userName));
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            roleList.Add(reader["RoleName"].ToString());
                        }
                         //roleListArray= roleList.ToArray();
                         Session["AssignedRolesforUser"] = roleList;
                        // HttpContext.Current.User = new GenericPrincipal(new GenericIdentity(HttpContext.Current.User.Identity.Name), roleListArray);
                        //return roleListArray;
                    }
                    
                }
                   
            //}
            //roleListArray = new string[1];
            //roleListArray= ["user",""];
            //return null;
        }
    }
}
