﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Consultancy
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //Event in MasterPage
        public delegate void SomethingSelected(object sender, String SelectedValue);
        public event SomethingSelected OnSomethingSelected;

        protected void ddlMasterTest_SelectedIndexChanged(object sender, EventArgs e)
        {
            OnSomethingSelected(sender, ((DropDownList)sender).SelectedValue);
        }

        //SelectedIndexChanged event in MasterPage
        //protected void DropDonwnList1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    OnSomethingSelected(sender, ((DropDownList)sender).SelectedValue);
        //}


    }
}
