﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Consultancy.Model
{
    public static class ModelObjects
    {
        public static int screenID { get; set; }
        public static int screenID_SelectedValue { get; set; }
        public static bool isUploadRequired { get; set; }
    }
}