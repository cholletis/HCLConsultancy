﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DALConsultancy;

namespace Consultancy.aspx
{
    public partial class HumanReources : System.Web.UI.Page
    {
        DALCompanyDetails _DALCompanyDetails = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                populateCompanyDetails();
            }
        }
        private void populateCompanyDetails()
        {
            _DALCompanyDetails = new DALCompanyDetails();
            ddlDivision.DataSource = _DALCompanyDetails.GetCompanyDetails(1);
            ddlDivision.DataTextField = "CompanyName";
            ddlDivision.DataValueField = "CompanyID";
            ddlDivision.DataBind();
        }
    }
}