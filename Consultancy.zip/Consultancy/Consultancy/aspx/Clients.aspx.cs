﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Consultancy.aspx
{
    public partial class Clients : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            tblAddCompany.Visible = false;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            tblAddCompany.Visible = true;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            tblAddCompany.Visible = false;
        }

        protected void ddlTest_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}