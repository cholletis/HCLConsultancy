﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DALConsultancy;
using Consultancy.Model;
using System.Data;
using Consultancy.UserControl;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Drawing;

namespace Consultancy.aspx
{
    public partial class CompanyDetails : System.Web.UI.Page
    {
        bool issuccess = false;
        DALCompanyDetails _DALCompanyDetails = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblSuccess.Text = string.Empty;
            lblFailure.Text = string.Empty;
            if (!IsPostBack)
            {
                tblAddCompany.Visible = false;
                populateCompanyDetails();
            }

        }
        private void populateCompanyDetails()
        {
            _DALCompanyDetails = new DALCompanyDetails();
            int HrCategory = Convert.ToInt16(ddlHRCategory.SelectedValue);
            ViewState["cmpnyDetails"] = _DALCompanyDetails.GetCompanyDetails(HrCategory);
            gridCompanyDetails.DataSource = ((DataTable)ViewState["cmpnyDetails"]);
            gridCompanyDetails.DataBind();
        }
        protected void btAddNewCompany_Click(object sender, EventArgs e)
        {
            tblAddCompany.Visible = true;
        }

        protected void btSaveCompany_Click(object sender, EventArgs e)
        {
            //_DALCompanyDetails = new DALCompanyDetails();
            //if (FileUploadCompany.HasFile)
            //{
            //    issuccess = _DALCompanyDetails.InsertCompanyDetails(txtCompanyName.Text, txtWebSite.Text, FileUploadCompany.FileName, "application/pdf", FileUploadCompany.FileBytes, 1);
               
            //}
            //else
            //{
            //    issuccess = _DALCompanyDetails.InsertCompanyDetails(txtCompanyName.Text, txtWebSite.Text, "", "", null, 1);
            //}
            //if (issuccess)
            //{
            //    populateCompanyDetails();
            //    tblAddCompany.Visible = false;
            //    displayMessage(issuccess, "Company details created successfully");
            //}
            //else
            //{
            //    displayMessage(issuccess, "An Error Occured while updating company details");
            //}
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ShowPopupAttachDocs(1,2);
            //Server.Transfer("AttachFile.aspx");
        }
        
        
            

        protected void ddlAttachmentsCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlCurrentDropDownList = (DropDownList)sender;
            GridViewRow grdrDropDownRow = ((GridViewRow)ddlCurrentDropDownList.Parent.Parent);
            int PageSelectedValue = Convert.ToInt32(gridCompanyDetails.DataKeys[grdrDropDownRow.RowIndex].Values["CompanyID"]); 
            if (ddlCurrentDropDownList.SelectedItem.Text == "Add New")
            {                 
                ShowPopupAttachDocs(1,PageSelectedValue);
                populateCompanyDetails();
            }
            //else if (ddlCurrentDropDownList.SelectedItem.Text == "Delete")
            //{
            //    //DeleteFiles ucSimpleControl = LoadControl("~/UserControl/DeleteFiles.ascx") as DeleteFiles;
            //    //PlaceHolder1.Controls.Add(ucSimpleControl);
            //    //ShowFilesUCforDelete(1,PageSelectedValue);
            //    populateCompanyDetails();                
            //}
           
        }
        
        //protected void btCancelDelete_Click(object sender, EventArgs e)
        //{
        //    PlaceHolder1.Controls[0].Dispose();
        //    //Server.Transfer("AttachFile.aspx");
        //}
        private void ShowPopupAttachDocs(int pageID,int pageSelectedValue)
        {
            ModelObjects.screenID = pageID;
            ModelObjects.screenID_SelectedValue = pageSelectedValue;
            ModalPopupExtender1.Show();
        }
        //private void ShowFilesUCforDelete(int pageID, int pageSelectedValue)
        //{
        //    ModelObjects.screenID = pageID;
        //    ModelObjects.screenID_SelectedValue = pageSelectedValue;
        //    ModalPopupExtenderDeleteFile.Show();
        //}


        protected void gridCompanyDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            _DALCompanyDetails = new DALCompanyDetails();
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DropDownList dl = (DropDownList)e.Row.FindControl("ddlAttachmentsCompany");
                if (dl != null)
                {
                    int PageSelectedValue = Convert.ToInt32(gridCompanyDetails.DataKeys[e.Row.RowIndex].Values["CompanyID"]);
                    DataTable dt = _DALCompanyDetails.GetAttachedFileList(1,PageSelectedValue);                    
                    dl.DataSource = dt;
                    dl.DataTextField = "FileName";
                    dl.DataValueField = "FileID";
                    dl.DataBind();

                    if (dt.Rows.Count > 0)
                    {
                        dl.Items.Insert(0, new ListItem("Please Select", "0"));                       
                    }
                    else
                    {
                        dl.Items.Insert(0, new ListItem("N/A", "0"));
                    }
                    dl.Items.Insert(1, new ListItem("Add New", "1"));
                    //dl.Items.Insert(2, new ListItem("Delete", "2"));
                    
                }
            }
        }

        protected void gridCompanyDetails_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            _DALCompanyDetails = new DALCompanyDetails();
            int result;
            if ((e.CommandArgument.ToString() != string.Empty) && int.TryParse(e.CommandArgument.ToString(), out result))
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = gridCompanyDetails.Rows[index];
                DropDownList dl = (DropDownList)row.FindControl("ddlAttachmentsCompany");
                if (e.CommandName == "DownLoadFile")
                {
                    if (dl != null && dl.SelectedIndex > 1)
                    {
                        DataTable dt = _DALCompanyDetails.DownLoadSelectedFile(Convert.ToInt32(dl.SelectedItem.Value));
                        if (dt.Rows.Count > 0)
                        {
                            Byte[] bytes = (Byte[])dt.Rows[0]["Data"];
                            Response.Buffer = true;
                            Response.Charset = "";
                            Response.Cache.SetCacheability(HttpCacheability.NoCache);
                            Response.ContentType = dt.Rows[0]["ContentType"].ToString();
                            Response.AddHeader("content-disposition", "attachment;filename="
                            + dt.Rows[0]["FileName"].ToString());
                            Response.BinaryWrite(bytes);
                            Response.Flush();
                            Response.End();
                        }
                    }

                }
                else if (e.CommandName == "DeleteFile")
                {
                    if (dl != null && dl.SelectedIndex > 1)
                    {
                        issuccess = _DALCompanyDetails.DeleteSelectedFile(Convert.ToInt32(dl.SelectedItem.Value));
                        if (issuccess)
                        {
                            displayMessage(issuccess, "File Deleted Successfully");
                            populateCompanyDetails();
                        }
                        else
                        {
                            displayMessage(issuccess, "An Error Occured While deleting File");
                        }
                    }

                }
            }
            //else if(e.CommandName == "AttachFile" )
            //{
            //    int index = Convert.ToInt32(e.CommandArgument);
            //    GridViewRow row = gridCompanyDetails.Rows[index];
            //    DropDownList dl = (DropDownList)row.FindControl("ddlAttachmentsCompany");
            //    if (dl != null && dl.SelectedIndex != -1)
            //    {
            //        int pageID = 1;
            //        int pageSelectedValue = Convert.ToInt32(gridCompanyDetails.DataKeys[e.Row.RowIndex].Values["CompanyID"]);
            //        if (dl.SelectedItem.Text == "Add New")
            //        {
            //            ShowPopupAttachDocs(pageID, pageSelectedValue);
            //        }
            //    }
            //}

        }

        protected void gridCompanyDetails_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gridCompanyDetails.EditIndex = e.NewEditIndex;
            populateCompanyDetails();
        }

        protected void gridCompanyDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            _DALCompanyDetails = new DALCompanyDetails();
            int CompanyID = Convert.ToInt32(gridCompanyDetails.DataKeys[e.RowIndex].Values["CompanyID"]);               
            string CompanyName = ((TextBox)gridCompanyDetails.Rows[e.RowIndex].FindControl("txtCompanyName")).Text;
            string WebSite = ((TextBox)gridCompanyDetails.Rows[e.RowIndex].FindControl("txtWebSite")).Text;
            bool isupdateSuccess = _DALCompanyDetails.UpdateCompanyDetails(CompanyName, WebSite, CompanyID);
            if (isupdateSuccess)
            {
                gridCompanyDetails.EditIndex = -1;
                populateCompanyDetails();
            }
        }

        protected void gridcompany_rowDeleting(object sender, EventArgs e)
        {
            _DALCompanyDetails = new DALCompanyDetails();
            LinkButton lnkRemove = (LinkButton)sender;
            int CompanyID =Convert.ToInt32(lnkRemove.CommandArgument);
            issuccess = _DALCompanyDetails.DeleteCompanyDetails(CompanyID,1);
            populateCompanyDetails();
            if (issuccess)
            {
                displayMessage(issuccess,"Deleted Company details Successfully");
            }
            else
            {
                displayMessage(issuccess,"An Error occured while deleting company details");
            }
            
        }

        protected void gridCompanyDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

        }

        protected void gridCompanyDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridCompanyDetails.EditIndex = -1;
            populateCompanyDetails();
        }
        private void displayMessage(bool isSuccess,string Message)
        {
            if (isSuccess)
            {
                lblSuccess.Text = Message;
                lblFailure.Text = string.Empty;
            }
            else
            {
                lblFailure.Text = Message;
                lblSuccess.Text = string.Empty;
            }
        }

        protected void ddlTest_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btSendMail_Click(object sender, EventArgs e)
        {
            try
            {
                //Create the msg object to be sent
                MailMessage msg = new MailMessage();
                //Add your email address to the recipients
                msg.To.Add("sureshch3112@gmail.com");
                //Configure the address we are sending the mail from
                MailAddress address = new MailAddress("mr@soundout.net");
                
                msg.From = address;
                
                msg.Subject = "Test Subject";
                msg.Body = "Test Body";

                SmtpClient client = new SmtpClient();
                //client.Host = "relay-hosting.secureserver.net";
                client.Host = "smtpout.secureserver.net";
                client.Port = 25;
                client.UseDefaultCredentials = false;
                NetworkCredential credentials = new NetworkCredential("GodaddyEmail@YourDomain.com", "YourPassword");
                client.Credentials = credentials;

                //Send the msg
                client.Send(msg);

                //Display some feedback to the user to let them know it was sent
                lblSuccess.Text = "Your message was sent!";
            }
            catch (Exception ex)
            {
                //If the message failed at some point, let the user know
                lblFailure.Text = ex.ToString(); //alt text "Your message failed to send, please try again."
            }
        }

        //ViewState["cmpnyDetails"]
        protected void txtHeaderCompanyName_TextChanged(object sender, EventArgs e)
        {
            DataTable dtCompanyDetails = (DataTable)(ViewState["cmpnyDetails"]);
            DataView dvFilteredCompanyDetails = dtCompanyDetails.DefaultView;
            StringBuilder  strFilter = new StringBuilder();
            string strfilterCompany = ((TextBox)gridCompanyDetails.HeaderRow.Cells[0].FindControl("txtHeaderCompanyName")).Text;
            string condition = string.Empty;
            
            if (strfilterCompany != string.Empty)
            {
                condition = "CompanyName Like '%" + strfilterCompany + "%'";                
                //dvFilteredCompanyDetails.RowFilter = "CompanyName Like '%" + strfilterCompany + "%'";                
            }
            string strfilterWebSite = ((TextBox)gridCompanyDetails.HeaderRow.Cells[0].FindControl("txtHeaderWebSite")).Text;
            if (strfilterWebSite != string.Empty)
            {
                condition = ((condition != string.Empty) ? condition + " AND " : string.Empty) + "WebSite Like '%" + strfilterWebSite + "%'";
               
            }
            dvFilteredCompanyDetails.RowFilter = condition;            
            dtCompanyDetails = (DataTable)dvFilteredCompanyDetails.ToTable();
            gridCompanyDetails.DataSource = dtCompanyDetails;

            gridCompanyDetails.DataBind();
            ((TextBox)gridCompanyDetails.HeaderRow.Cells[0].FindControl("txtHeaderCompanyName")).Text = strfilterCompany;
            ((TextBox)gridCompanyDetails.HeaderRow.Cells[0].FindControl("txtHeaderWebSite")).Text = strfilterWebSite;
            //populateCompanyDetails();
        }
        //public override void VerifyRenderingInServerForm(Control control)
        //{
        //    //Allows for printing
        //}
        //public override bool EnableEventValidation
        //{
        //    get { return false; }
        //    set { /*Do nothing*/ }
        //}


        protected void btExport_Click(object sender, EventArgs e)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                gridCompanyDetails.AllowPaging = false;
                //this.populateCompanyDetails();

                gridCompanyDetails.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in gridCompanyDetails.HeaderRow.Cells)
                {
                    cell.BackColor = gridCompanyDetails.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in gridCompanyDetails.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = gridCompanyDetails.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = gridCompanyDetails.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gridCompanyDetails.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }

        protected void btExitHR_Click(object sender, EventArgs e)
        {
            _DALCompanyDetails = new DALCompanyDetails();
            Button btnExit = (Button)sender;
            int CompanyID = Convert.ToInt32(btnExit.CommandArgument);
            issuccess = _DALCompanyDetails.ExitCompanyDetails(CompanyID);
            populateCompanyDetails();
            if (issuccess)
            {
                displayMessage(issuccess, "Exited Company details Successfully");
            }
            else
            {
                displayMessage(issuccess, "An Error occured while Exiting company details");
            }
            
        }

        protected void ddlHRCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            populateCompanyDetails();
        }
        //protected override void Render(HtmlTextWriter writer)
        //{
        //    Page.ClientScript.GetPostBackEventReference(ddlTest, "");
        //    ddlTest.Attributes.Add("onchange", "__doPostBack('" + ddlTest.UniqueID + "','');");
        //    Page.ClientScript.RegisterForEventValidation(ddlTest.UniqueID);
        //    base.Render(writer);
        //}
    }
}