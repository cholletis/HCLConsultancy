﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Consultancy.aspx
{
    public partial class TestJquery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {            
            Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            DropDownList thisDropDown = this.Master.FindControl("ddlMasterTest") as DropDownList;
            if (!IsPostBack)
            {                
                //DropDownList drp = (DropDownList)Page.Master.FindControl("ddlMasterTest");
                //drp.SelectedIndexChanged += new EventHandler(drp_SelectedIndexChanged);
            }
        }

        protected void drp_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblErrorMesg.InnerText = ((DropDownList)sender).SelectedItem.Text;
        }

        protected void btTest_Click(object sender, EventArgs e)
        {
            int divisor = 0;
            int result = 1 / divisor;
        }
        protected void Page_Init(object sender, EventArgs e)
        {
            var master = (SiteMaster)Page.Master;
            master.OnSomethingSelected += MasterSelected;
        }

        private void MasterSelected(object sender, string selectedValue)
        {
            lblErrorMesg.InnerText = ((DropDownList)sender).SelectedItem.Text;
        }

        //protected override void Page_Error(object sender, EventArgs e)
        //{
        //    Exception ex = Server.GetLastError();
        //    lblErrorMesg.InnerText = ex.Message;
        //} 


    }
}