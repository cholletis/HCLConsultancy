﻿
$(document).ready(function () {
    $('[id$=btTest]').click(function () {
        alert("Clicked");
        var friends = ["Mike", "Stacy", "Andy", "Rick"];​
            friends.forEach(function (eachName, index){
            alert(index + 1 + ". " + eachName); 
            });
        return true;
    });
});